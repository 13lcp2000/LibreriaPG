/* 
var miLbro1 = new Object(){;
  mi libro.isbn        = "";
  mi libro.nombre      = "";
  mi libro.editorial   = "";
  mi libro.autores     = "";
  mi libro.fecha_publi = "";
}

var miLbro1 = new Object(){;
  mi libro["isbn          = "";
  mi libro["nombre        = "";
  mi libro["editorial     = "";
  mi libro["autores       = "";
  mi libro["fecha_publi"] = "";
}
*/
 function Libro(){
 	this.isbn        = "";
 	this.nombre      = "";
 	this.editorial   = "";
 	this.autores     = "";
 	this.fecha_publi = "";
 }
